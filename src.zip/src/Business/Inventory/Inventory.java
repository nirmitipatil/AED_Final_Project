/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Inventory;

/**
 *
 * @author Harshit
 */
public class Inventory {

    private String ingredientName;
    private int quantity;
    private String restaurantName;
    
    public Inventory(String ingredientName, int quantity, String restaurantName  ){
        this.ingredientName = ingredientName;
        this.quantity = quantity;
        this.restaurantName = restaurantName;
    }

    public String getIngredientName() {
        return ingredientName;
    }

    public void setIngredientName(String ingredientName) {
        this.ingredientName = ingredientName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getRestaurantName() {
        return restaurantName;
    }

    public void setRestaurantName(String restaurantName) {
        this.restaurantName = restaurantName;
    }
    
}
