
package userinterface.CustomerRole;

import Business.Customer.Customer;
import Business.Customer.CustomerDirectory;
import Business.DeliveryMan.DeliveryManDirectory;
import Business.EcoSystem;
import Business.Menu.Menu;
import Business.Menu.MenuDirectory;
import Business.Order.Order;
import Business.Order.OrderDirectory;
import Business.Restaurant.Restaurant;
import Business.Restaurant.RestaurantDirectory;
import Business.UserAccount.UserAccount;
import Business.WorkQueue.WorkRequest;
import java.awt.CardLayout;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Talre
 */
public class CustomerDeliveryJPanel extends javax.swing.JPanel {

    private JPanel userProcessContainer;
    private EcoSystem ecoSystem;
    private UserAccount account;
    private CustomerDirectory customerDirectory;
    private RestaurantDirectory restaurantDirectory;
    private DeliveryManDirectory deliveryManDirectory;
    private MenuDirectory menuDirectory;
    private OrderDirectory orderDirectory;
    private static int count = 1;
   
    public CustomerDeliveryJPanel(JPanel userProcessContainer, UserAccount account, EcoSystem ecoSystem, 
            CustomerDirectory customerDirectory, RestaurantDirectory restaurantDirectory, 
            DeliveryManDirectory deliveryManDirectory, MenuDirectory menuDirectory, OrderDirectory orderDirectory) {
        initComponents();
        
        this.userProcessContainer = userProcessContainer;
        this.account = account;
        this.ecoSystem = ecoSystem;
        this.customerDirectory = ecoSystem.getCustomerDirectory();
        this.restaurantDirectory = ecoSystem.getRestaurantDirectory();
        this.menuDirectory = ecoSystem.getMenuDirectory();
        this.deliveryManDirectory = ecoSystem.getDeliveryManDirectory();
        this.orderDirectory = ecoSystem.getOrderDirectory();
        this.setBounds(30, 30, 300, 300);
        valueLabel.setText(account.getUsername());
        populateRequestTable();
        populateRestaurantCombo();
        
        
    }
    
    public void populateTable() {
        DefaultTableModel dTableModel = (DefaultTableModel) tblItem.getModel();
        dTableModel.setRowCount(0);
        String restaurantName = boxRestaurant.getSelectedItem().toString();
        Restaurant restaurant = ecoSystem.getRestaurantDirectory().getRestaurant(restaurantName);
        HashMap<String, Integer> restaurantInventory = restaurant.getInventory();
        Iterator<Map.Entry<String, Integer>> itrInventory = restaurantInventory.entrySet().iterator();
        for(Menu menu : ecoSystem.getMenuDirectory().getMenuDirectory()){
            if(restaurant.getRestaurantName().equals(menu.getRestaurantName())) {
                
                HashMap<String, Integer> ingredients = menu.getIngredients();
                Iterator<Map.Entry<String, Integer>> itrMenu = ingredients.entrySet().iterator();
                while(itrMenu.hasNext()){
                    Map.Entry<String, Integer> entry = itrMenu.next();
                    if(restaurantInventory.get(entry.getKey()) > entry.getValue()){
                        
                        Object [] row = new Object[2];
                        row[0] = menu;
                        row[1] = menu.getPrice();
                        dTableModel.addRow(row);
                        break;
                    }
                    
                    
                    
                }
                
                
                
                
                
            }
        }
    }
    
    public void populateRestaurantCombo() {
        boxRestaurant.removeAllItems();
        boxRestaurant.addItem("  ");
        for(Restaurant res : ecoSystem.getRestaurantDirectory().getRestaurantDirectory()) {
            //System.out.println("res" + res);
            boxRestaurant.addItem(res.getRestaurantName());
        }
    }
    
    public void populateRequestTable(){
        DefaultTableModel model = (DefaultTableModel) workRequestJTable.getModel();
        model.setRowCount(0);
        for (Order order : ecoSystem.getOrderDirectory().getOrderDirectory()){
            //System.out.println("Order" + order.getOrderId());
            if(account.getEmployee().getName().equals(order.getCustomer().getName())) {
                Object[] row = new Object[8];
                row[0] = order;
                row[1] = order.getMenu().getItemName();
                row[2] = order.getQuantity() * order.getMenu().getPrice();
                row[3] = order.getRestaurant().getRestaurantName();
                row[4] = order.getMessage();
                row[5] = order.getCustomer().getName();
                row[6] = order.getOrderStatus();
                row[7] = order.getQuantity();
                model.addRow(row);
            }
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        workRequestJTable = new javax.swing.JTable();
        requestTestJButton = new javax.swing.JButton();
        refreshTestJButton = new javax.swing.JButton();
        enterpriseLabel = new javax.swing.JLabel();
        valueLabel = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblItem = new javax.swing.JTable();
        boxRestaurant = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        txtQuantity = new javax.swing.JTextField();
        btnConfirm = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        txtComment = new javax.swing.JTextField();
        btnMenuShow = new javax.swing.JButton();
        enterpriseLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 204, 153));
        setPreferredSize(new java.awt.Dimension(980, 590));
        setLayout(null);

        workRequestJTable.setBackground(new java.awt.Color(204, 204, 204));
        workRequestJTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Order ID", "ItemName", "Price", "Restaurant", "Message", "Receiver", "Status", "Quantity"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        workRequestJTable.setPreferredSize(new java.awt.Dimension(390, 128));
        jScrollPane1.setViewportView(workRequestJTable);
        if (workRequestJTable.getColumnModel().getColumnCount() > 0) {
            workRequestJTable.getColumnModel().getColumn(4).setResizable(false);
        }

        add(jScrollPane1);
        jScrollPane1.setBounds(15, 444, 1216, 154);

        requestTestJButton.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        requestTestJButton.setText("Add Comment");
        requestTestJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                requestTestJButtonActionPerformed(evt);
            }
        });
        add(requestTestJButton);
        requestTestJButton.setBounds(540, 639, 159, 41);

        refreshTestJButton.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        refreshTestJButton.setText("Refresh");
        refreshTestJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshTestJButtonActionPerformed(evt);
            }
        });
        add(refreshTestJButton);
        refreshTestJButton.setBounds(578, 351, 121, 61);

        enterpriseLabel.setFont(new java.awt.Font("Optima", 1, 18)); // NOI18N
        enterpriseLabel.setText("Select Resturant: ");
        add(enterpriseLabel);
        enterpriseLabel.setBounds(21, 95, 154, 30);

        valueLabel.setFont(new java.awt.Font("Optima", 1, 18)); // NOI18N
        valueLabel.setText("<value>");
        add(valueLabel);
        valueLabel.setBounds(440, 48, 158, 26);

        tblItem.setBackground(new java.awt.Color(204, 204, 204));
        tblItem.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tblItem.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Item Name", "Price"
            }
        ));
        jScrollPane2.setViewportView(tblItem);

        add(jScrollPane2);
        jScrollPane2.setBounds(21, 172, 733, 150);

        boxRestaurant.setFont(new java.awt.Font("Optima", 0, 14)); // NOI18N
        boxRestaurant.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        boxRestaurant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxRestaurantActionPerformed(evt);
            }
        });
        add(boxRestaurant);
        boxRestaurant.setBounds(179, 99, 214, 25);

        jLabel1.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        jLabel1.setText("Quantity:");
        add(jLabel1);
        jLabel1.setBounds(21, 377, 81, 24);
        add(txtQuantity);
        txtQuantity.setBounds(132, 382, 162, 20);

        btnConfirm.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        btnConfirm.setText("Confirm");
        btnConfirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmActionPerformed(evt);
            }
        });
        add(btnConfirm);
        btnConfirm.setBounds(378, 351, 139, 61);

        jLabel2.setFont(new java.awt.Font("Optima", 1, 18)); // NOI18N
        jLabel2.setText("Comment:");
        add(jLabel2);
        jLabel2.setBounds(23, 647, 93, 24);
        add(txtComment);
        txtComment.setBounds(134, 652, 358, 20);

        btnMenuShow.setBackground(new java.awt.Color(255, 255, 255));
        btnMenuShow.setFont(new java.awt.Font("Lucida Grande", 1, 18)); // NOI18N
        btnMenuShow.setText("Show Menu");
        btnMenuShow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMenuShowActionPerformed(evt);
            }
        });
        add(btnMenuShow);
        btnMenuShow.setBounds(505, 94, 135, 33);

        enterpriseLabel1.setFont(new java.awt.Font("Optima", 1, 18)); // NOI18N
        enterpriseLabel1.setText("Customer :");
        add(enterpriseLabel1);
        enterpriseLabel1.setBounds(307, 46, 127, 30);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Customers.png"))); // NOI18N
        add(jLabel3);
        jLabel3.setBounds(909, 94, 258, 281);

        btnBack.setText("<Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        add(btnBack);
        btnBack.setBounds(21, 64, 63, 23);
    }// </editor-fold>//GEN-END:initComponents

    private void requestTestJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_requestTestJButtonActionPerformed

        if(txtComment.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null,"Field cannot be empty");
            return;
        }
        
        int selectedRow = workRequestJTable.getSelectedRow();
        if(selectedRow < 0) {
            JOptionPane.showMessageDialog(null,"Please Select a row from table first", "Warining", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        Order order = (Order)workRequestJTable.getValueAt(selectedRow, 0);
        order.setMessage(txtComment.getText());
        populateRequestTable();
    }//GEN-LAST:event_requestTestJButtonActionPerformed

    private void refreshTestJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshTestJButtonActionPerformed

        populateRequestTable();
        
    }//GEN-LAST:event_refreshTestJButtonActionPerformed

    private void boxRestaurantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxRestaurantActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_boxRestaurantActionPerformed

    private void btnConfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmActionPerformed
        // TODO add your handling code here:
         int selectedRow = tblItem.getSelectedRow();
         
        if(selectedRow < 0) {
            JOptionPane.showMessageDialog(null,"Please Select a row from table first", "Warining", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int quantity = Integer.parseInt(txtQuantity.getText());
        if(quantity >15){
            JOptionPane.showMessageDialog(null,"Sorry you cannot order more than 15 quantities per order", "Warining", JOptionPane.WARNING_MESSAGE);
            
            return;
        }
        
        String restaurantName = boxRestaurant.getSelectedItem().toString();
        
        Restaurant restaurant = ecoSystem.getRestaurantDirectory().getRestaurant(restaurantName);
        HashMap<String, Integer> restaurantInventory = restaurant.getInventory();
        
        Customer customer = ecoSystem.getCustomerDirectory().getCustomer(account.getEmployee().getName());
        Menu menu = (Menu) tblItem.getValueAt(selectedRow, 0);
        
        HashMap<String, Integer> ingredients = menu.getIngredients();
                Iterator<Map.Entry<String, Integer>> itrMenu = ingredients.entrySet().iterator();
                while(itrMenu.hasNext()){
                    Map.Entry<String, Integer> entry = itrMenu.next();
                    restaurantInventory.put(entry.getKey(),restaurantInventory.get(entry.getKey()) - (quantity*entry.getValue()) );
                     
                }
                System.out.println(restaurantInventory);
        
        String status = "Order Placed";
        
        Order order = ecoSystem.getOrderDirectory().newOrder();
        order.setCustomer(customer);
        order.setOrderId(String.valueOf(count++));
        order.setQuantity(quantity);
        order.setMenu(menu);
        order.setRestaurant(restaurant);
        order.setOrderStatus(status);
        order.setAssign(false);
        
        JOptionPane.showMessageDialog(null,"You have placed an order");
        populateRequestTable();
                
    }//GEN-LAST:event_btnConfirmActionPerformed

    private void btnMenuShowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMenuShowActionPerformed
        // TODO add your handling code here:
        if(boxRestaurant.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(null, "Please select a restaurant");
            return;
        }
        populateTable();
    }//GEN-LAST:event_btnMenuShowActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        // TODO add your handling code here:
        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBackActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> boxRestaurant;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnConfirm;
    private javax.swing.JButton btnMenuShow;
    private javax.swing.JLabel enterpriseLabel;
    private javax.swing.JLabel enterpriseLabel1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton refreshTestJButton;
    private javax.swing.JButton requestTestJButton;
    private javax.swing.JTable tblItem;
    private javax.swing.JTextField txtComment;
    private javax.swing.JTextField txtQuantity;
    private javax.swing.JLabel valueLabel;
    private javax.swing.JTable workRequestJTable;
    // End of variables declaration//GEN-END:variables
}
